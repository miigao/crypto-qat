Bibtex for publications that use CUDPP          {#cudpp_refs_bib}
======================================

@htmlinclude doc/bib/cudpp_refs_bib.html

